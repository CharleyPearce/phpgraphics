<?php

require '/xampp/vendor/autoload.php';
use SVG\SVG;
use SVG\Nodes\Shapes\SVGRect;
use SVG\Nodes\Shapes\SVGPolygon;
include("Vector3.php");
include("Matrix4.php");

function random_color_part() {
    return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
}

function random_color() {
    return "#" . random_color_part() . random_color_part() . random_color_part();
}

// $vec = new Vector3(1, 2, 3);

$mat = new Matrix4(
    array(
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1,
    )
);

$viewWidth = 800;
$viewHeight = 800;

$cube = array(
    array(
        new Vector3(1, 1, -1),
        new Vector3(1, -1, -1),
        new Vector3(-1, -1, -1),
        new Vector3(-1, 1, -1)
    ),
    array(
        new Vector3(-1, -1, -1),
        new Vector3(-1, -1, 1),
        new Vector3(1, -1, 1),
        new Vector3(1, -1, -1)
    ),

    array(
        new Vector3(-1, 1, -1),
        new Vector3(-1, -1, -1),
        new Vector3(-1, -1, 1),
        new Vector3(-1, 1, 1)
    ),

    array(
        new Vector3(1, 1, -1),
        new Vector3(1, -1, -1),
        new Vector3(1, -1, 1),
        new Vector3(1, 1, 1)
    ),
    array(
        new Vector3(-1, 1, -1),
        new Vector3(-1, 1, 1),
        new Vector3(1, 1, 1),
        new Vector3(1, 1, -1)
    ),
    array(
        new Vector3(1, 1, 1),
        new Vector3(1, -1, 1),
        new Vector3(-1, -1, 1),
        new Vector3(-1, 1, 1)
    ),
);

// model matrix: transform object from local space coordinates to world space
$model1 = Matrix4::Translate(new Vector3(3, -3, -5));
$model2 = Matrix4::Translate(new Vector3(-3, -3, -1))->matrixMatrixMultiply(Matrix4::rotate(20, new Vector3(1, 1, 1)));
$model3 = Matrix4::Translate(new Vector3(-3, 3, -1))->matrixMatrixMultiply(Matrix4::Scale(new Vector3(0.5, 1, 1)));

// vew matrix: the position/angle of the camera
$view = Matrix4::Translate(new Vector3(0, 0, -10 ))->matrixMatrixMultiply(Matrix4::rotate(15, new Vector3(0, 1, 0)));

// projection matrix: the projection to be used
$proj = Matrix4::Perspective(1, 100, $viewWidth/$viewHeight, 90);


for ($i = 0; $i < 16; $i++) {
    // echo $mvp->val($i).", ";
    if ($i %4 == 3){
        // echo "<br>";
    }
}

// image with 100x100 viewport
$image = new SVG($viewWidth, $viewHeight);
$doc = $image->getDocument();

for ($k = -31; $k < -6; $k +=2) {
    for ($i = 0; $i < count($cube); $i++) {
        for ($j = 0; $j < count($cube[$i]); $j++) {
            $model4 = Matrix4::Translate(new Vector3(3, -3, $k));

            $mvp = ($proj->matrixMatrixMultiply($view))->matrixMatrixMultiply($model4);
            $newTris[$i][$j] = $mvp->matrixVectorMultiply($cube[$i][$j]);

            $points[$i][$j][0] = abs($newTris[$i][$j]->X() * $viewWidth + $viewWidth / 2);
            $points[$i][$j][1] = abs($newTris[$i][$j]->Y() * $viewHeight + $viewHeight / 2);

            // echo $points[$i][$j][0]. ", ";
            // echo $points[$i][$j][1]. ", ";
            // echo "<br>";
        }
        $poly = new SVGPolygon($points[$i]);
        $poly->setStyle('fill', random_color());
        $doc->addChild($poly);
    }
}
for ($i = 0; $i < count($cube); $i++) {
    for($j = 0; $j < count($cube[$i]); $j++) {
        $mvp = ($proj->matrixMatrixMultiply($view))->matrixMatrixMultiply($model1);
        $newTris[$i][$j] = $mvp->matrixVectorMultiply($cube[$i][$j]);

        $points[$i][$j][0] = abs($newTris[$i][$j]->X() * $viewWidth + $viewWidth/2);
        $points[$i][$j][1] = abs($newTris[$i][$j]->Y() * $viewHeight + $viewHeight/2);

        // echo $points[$i][$j][0]. ", ";
        // echo $points[$i][$j][1]. ", ";
        // echo "<br>";
    }
    $poly = new SVGPolygon($points[$i]);
    $poly->setStyle('fill', random_color());
    $doc->addChild($poly);
}

for($i = 0; $i < count($cube); $i++) {
    for($j = 0; $j < count($cube[$i]); $j++) {
        $mvp = ($proj->matrixMatrixMultiply($view))->matrixMatrixMultiply($model3);
        $newTris[$i][$j] = $mvp->matrixVectorMultiply($cube[$i][$j]);

        $points[$i][$j][0] = abs($newTris[$i][$j]->X() * $viewWidth + $viewWidth/2);
        $points[$i][$j][1] = abs($newTris[$i][$j]->Y() * $viewHeight + $viewHeight/2);

        // echo $points[$i][$j][0]. ", ";
        // echo $points[$i][$j][1]. ", ";
        // echo "<br>";
    }
    $poly = new SVGPolygon($points[$i]);
    $poly->setStyle('fill', random_color());
    $doc->addChild($poly);
}

for($i = 0; $i < count($cube); $i++) {
    for($j = 0; $j < count($cube[$i]); $j++) {
        $mvp = ($proj->matrixMatrixMultiply($view))->matrixMatrixMultiply($model2);
        $newTris[$i][$j] = $mvp->matrixVectorMultiply($cube[$i][$j]);

        $points[$i][$j][0] = abs($newTris[$i][$j]->X() * $viewWidth + $viewWidth/2);
        $points[$i][$j][1] = abs($newTris[$i][$j]->Y() * $viewHeight + $viewHeight/2);

        // echo $points[$i][$j][0]. ", ";
        // echo $points[$i][$j][1]. ", ";
        // echo "<br>";
    }
    $poly = new SVGPolygon($points[$i]);
    $poly->setStyle('fill', random_color());
    $doc->addChild($poly);
}

header('Content-Type: image/svg+xml');
echo $image;
